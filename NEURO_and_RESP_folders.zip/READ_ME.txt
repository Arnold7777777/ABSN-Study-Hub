NEURO + RESP FOLDERS
====================
These two folders were stuck inside zips you had uploaded to the repo.
I pulled them out for you so you don't have to hunt for them.

Upload these together with the "more" folder and "infographics.html"
from the STEP1 zip. See the step-by-step in the chat.

Do NOT open these folders and drag what's inside - drag the folder
itself, or the index.html inside will overwrite your homepage.
